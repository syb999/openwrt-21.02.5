#!/bin/sh
# 给每个桌面用户放一个「玩客云 USB 烧录」桌面图标（Mint/Cinnamon 的 Nemo 还要求
# 标记 metadata::trusted，否则双击只当文本打开）。
#
#   desktop-icon.sh                 装（deb 的 postinst 调）
#   desktop-icon.sh --remove        删（postrm 调）
#   desktop-icon.sh --user U --home DIR   只处理指定用户/目录（测试用）
set -u

SRC="${ONECLOUD_DESKTOP_SRC:-/usr/share/applications/onecloud-flasher.desktop}"   # 测试时可覆盖
NAME=onecloud-flasher.desktop
MODE=install

while [ $# -gt 0 ]; do
    case "$1" in
        --remove) MODE=remove ;;
        --user) USER_ONE="$2"; shift ;;
        --home) HOME_ONE="$2"; shift ;;
        *) ;;
    esac
    shift
done

desktop_dir_for() {
    home="$1"
    d=""
    if [ -f "$home/.config/user-dirs.dirs" ]; then
        d=$(sed -n 's/^XDG_DESKTOP_DIR="\(.*\)"$/\1/p' "$home/.config/user-dirs.dirs" 2>/dev/null | head -1)
        d=$(printf '%s' "$d" | sed "s|^\\\$HOME|$home|; s|^\\\\\$HOME|$home|")
    fi
    if [ -z "$d" ] || [ ! -d "$d" ]; then
        if [ -d "$home/桌面" ]; then d="$home/桌面"
        elif [ -d "$home/Desktop" ]; then d="$home/Desktop"
        else d=""; fi
    fi
    printf '%s' "$d"
}

mark_trusted() {
    u="$1"; f="$2"
    [ "$(id -u)" = "0" ] || return 0
    command -v gio >/dev/null 2>&1 || return 0
    command -v runuser >/dev/null 2>&1 || return 0
    uid=$(id -u "$u" 2>/dev/null) || return 0
    bus="unix:path=/run/user/$uid/bus"
    [ -S "/run/user/$uid/bus" ] || bus=""
    runuser -u "$u" -- env ${bus:+DBUS_SESSION_BUS_ADDRESS=$bus} DISPLAY="${DISPLAY:-:0}" \
        gio set "$f" metadata::trusted true >/dev/null 2>&1 || true
}

handle_user() {
    u="$1"; home="$2"
    [ -n "$u" ] && [ -n "$home" ] && [ -d "$home" ] || return 0
    desk=$(desktop_dir_for "$home")
    [ -n "$desk" ] && [ -d "$desk" ] || return 0
    target="$desk/$NAME"

    if [ "$MODE" = remove ]; then
        rm -f "$target" 2>/dev/null || true
        return 0
    fi

    [ -f "$SRC" ] || return 0
    cp -f "$SRC" "$target" 2>/dev/null || return 0
    chmod 755 "$target" 2>/dev/null || true
    if [ "$(id -u)" = "0" ]; then
        grp=$(id -gn "$u" 2>/dev/null) || grp=""
        chown "$u"${grp:+:$grp} "$target" 2>/dev/null || true
    fi
    mark_trusted "$u" "$target"
}

if [ -n "${USER_ONE:-}" ]; then
    h="${HOME_ONE:-}"
    [ -n "$h" ] || h=$(getent passwd "$USER_ONE" 2>/dev/null | cut -d: -f6)
    handle_user "$USER_ONE" "$h"
    exit 0
fi

# 所有普通用户（uid>=1000，排除 nobody 65534）
getent passwd 2>/dev/null | awk -F: '$3>=1000 && $3<65534 {print $1":"$6}' | while IFS=: read -r u h; do
    handle_user "$u" "$h"
done

exit 0
