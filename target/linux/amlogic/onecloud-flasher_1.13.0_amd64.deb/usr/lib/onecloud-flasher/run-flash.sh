#!/bin/sh
# 由 pkexec 以 root 调用：设置自带 libusb 的搜索路径后执行 aml-flash。
# pkexec 会清掉环境变量，所以 LD_LIBRARY_PATH 必须在这里设。
set -e
D=$(cd "$(dirname "$0")" && pwd)

IMG="$1"
PARTS="${2:-all}"
RESET="${3:-1}"

[ -n "$IMG" ] || { echo "用法: run-flash.sh <镜像> [parts] [reset]" >&2; exit 2; }
[ -f "$IMG" ] || { echo "找不到镜像: $IMG" >&2; exit 2; }

# aml-flash 会把整个镜像解包到一个临时目录（要镜像那么大的空间）。
# 默认 /tmp；/tmp 装不下就改用镜像所在目录，避免出现 "No space left on device"。
IMG_KB=$(( $(stat -c %s "$IMG") / 1024 + 2048 ))
TMPFREE=$(df -Pk /tmp 2>/dev/null | awk 'NR==2 {print $4}')
if [ -z "$TMPFREE" ] || [ "$TMPFREE" -lt "$IMG_KB" ]; then
    IMGDIR=$(cd "$(dirname "$IMG")" && pwd)
    DIRFREE=$(df -Pk "$IMGDIR" 2>/dev/null | awk 'NR==2 {print $4}')
    if [ -n "$DIRFREE" ] && [ "$DIRFREE" -ge "$IMG_KB" ]; then
        TMPDIR="$IMGDIR"
        echo "== /tmp 剩余 ${TMPFREE:-?} KB，不足解包 ${IMG_KB} KB，临时目录改到 $TMPDIR"
    else
        echo "== 警告：/tmp 和 $IMGDIR 的可用空间都小于 ${IMG_KB} KB，可能会失败" >&2
    fi
fi
TMPDIR="${TMPDIR:-/tmp}"
export TMPDIR

# 清掉上次残留（厂商脚本退出时不删）
rm -rf "$TMPDIR"/aml-flash-tool-* 2>/dev/null || true

LD_LIBRARY_PATH="$D/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH
LC_ALL=C
export LC_ALL

# 进度必须实时：tools/update 用 "\r" 刷新 "Downloading %NN"，而 stdout 既不是
# 无缓冲也不是"每次 printf 就 flush"——管道下是 4KB 块缓冲，挂 pty 也只是行缓冲
# （行缓冲只在 '\n' flush，进度用的是 '\r'，照样憋到结束才吐 → GUI 里整个 rootfs
# 阶段一片空白，只有刷完那一瞬刷屏）。实测对比：
#     管道           1.5s 内 0 行
#     pty            1.5s 内 0 行
#     stdbuf -o0     1.5s 内全部行
# stdbuf 通过 LD_PRELOAD 生效，会一路传给孙子进程 tools/update。
STDBUF=""
command -v stdbuf >/dev/null 2>&1 && STDBUF="stdbuf -o0 -e0"

# 不用 exec：要把厂商脚本的临时目录收干净（它只在成功路径末尾自己删）
set +e
$STDBUF "$D/aml-flash" --img="$IMG" --soc=m8 --parts="$PARTS" --reset="$RESET"
rc=$?
set -e
rm -rf "$TMPDIR"/aml-flash-tool-* 2>/dev/null || true
exit $rc
